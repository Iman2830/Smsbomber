# Free RDP 6 HOURS
it's all free, don't be stingy ⭐️ yes: D

### HOW TO CREATE
```
> Press the Fork button to create RDP (For Android / HP Users, Please Use Desktop Mode).

> visit https://dashboard.ngrok.com and signup to get NGROK_AUTH_TOKEN

> Inside this Repo Go to Settings> and go Secrets> next> New repository secret

> Fill in the Name: Enter NGROK_AUTH_TOKEN

> Fill in Value: Visit https://dashboard.ngrok.com/auth/your-authtoken Copy and Paste in the value

> Press Add secret 

> Go to Action> > Run workflow

> Refresh Web and go to > build

> Press Down facing arrow button "RDP INFO LOGIN" To Get IP, User, Password.
```
### WARN

THIS IS ONLY FOR EDUCATIONAL PURPOSES

DON'T USE FOR MINING OR ILLEGAL USE
